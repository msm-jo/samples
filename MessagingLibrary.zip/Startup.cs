
using MassTransit;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

public class Startup
{
    public IConfiguration Configuration { get; }

    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public void ConfigureServices(IServiceCollection services)
    {
        var isDevelopment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";
        MassTransitConfig.Configure(services, Configuration, isDevelopment);

        services.AddSingleton<IMessageSerializer, JsonMessageSerializer>();
        services.AddTransient<IMessagePublisher, MessagePublisher>();
        services.AddTransient<IMessageConsumer, MessageConsumer>();
    }
}
