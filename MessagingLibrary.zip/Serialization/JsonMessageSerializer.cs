
using Newtonsoft.Json;

public class JsonMessageSerializer : IMessageSerializer
{
    public string Serialize<T>(T message) where T : class
    {
        return JsonConvert.SerializeObject(message);
    }

    public T Deserialize<T>(string message) where T : class
    {
        return JsonConvert.DeserializeObject<T>(message);
    }
}

public interface IMessageSerializer
{
    string Serialize<T>(T message) where T : class;
    T Deserialize<T>(string message) where T : class;
}
