
public interface IMessageConsumer
{
    void Consume<T>() where T : class;
}
