
using MassTransit;

public class MessageConsumer : IMessageConsumer
{
    private readonly IBusControl _busControl;
    private readonly IMessageSerializer _serializer;

    public MessageConsumer(IBusControl busControl, IMessageSerializer serializer)
    {
        _busControl = busControl;
        _serializer = serializer;
    }

    public void Consume<T>() where T : class
    {
        _busControl.ConnectReceiveEndpoint(typeof(T).Name, cfg =>
        {
            cfg.Handler<T>(context =>
            {
                var message = context.Message;
                return Task.CompletedTask;
            });
        });
    }
}
