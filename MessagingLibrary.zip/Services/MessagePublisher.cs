
using MassTransit;
using System.Threading.Tasks;

public class MessagePublisher : IMessagePublisher
{
    private readonly IPublishEndpoint _publishEndpoint;
    private readonly IMessageSerializer _serializer;

    public MessagePublisher(IPublishEndpoint publishEndpoint, IMessageSerializer serializer)
    {
        _publishEndpoint = publishEndpoint;
        _serializer = serializer;
    }

    public async Task Publish<T>(T message) where T : class
    {
        var serializedMessage = _serializer.Serialize(message);
        await _publishEndpoint.Publish(message);
    }
}
