using MessagingLibrary;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MessagingApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MessagingController : ControllerBase
    {
        private readonly IMessagingService _messagingService;

        public MessagingController(IMessagingService messagingService)
        {
            _messagingService = messagingService;
        }

        [HttpPost("send")]
        public async Task<IActionResult> SendMessage([FromBody] Order order)
        {
            await _messagingService.PublishMessageAsync(order);
            return Ok();
        }

        [HttpGet("receive")]
        public IActionResult GetLastMessage()
        {
            var message = GenericConsumer<Order>.GetLastMessage();
            if (message == null)
            {
                return NotFound("No message received yet.");
            }

            return Ok(message);
        }
    }
}
