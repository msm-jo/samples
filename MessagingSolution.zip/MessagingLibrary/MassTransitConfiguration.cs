using MassTransit;
using Microsoft.Extensions.DependencyInjection;

namespace MessagingLibrary
{
    public static class MassTransitConfiguration
    {
        public static IServiceCollection AddMassTransitWithRabbitMq(this IServiceCollection services, string rabbitMqUri)
        {
            services.AddMassTransit(x =>
            {
                x.AddConsumer(typeof(GenericConsumer<MessageEnvelope>));

                x.UsingRabbitMq((context, cfg) =>
                {
                    cfg.Host(rabbitMqUri);

                    cfg.ReceiveEndpoint("order-queue", e =>
                    {
                        e.ConfigureConsumer<GenericConsumer<MessageEnvelope>>(context);
                    });
                });
            });

            services.AddMassTransitHostedService();

            return services;
        }
    }
}
