using MassTransit;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace MessagingLibrary
{
    public class MessagingService : IMessagingService
    {
        private readonly IBusControl _busControl;

        public MessagingService(IBusControl busControl)
        {
            _busControl = busControl;
        }

        public async Task PublishMessageAsync<T>(T message) where T : class
        {
            var sendEndpoint = await _busControl.GetSendEndpoint(new Uri($"queue:{typeof(T).Name.ToLower()}-queue"));
            string serializedMessage = JsonConvert.SerializeObject(message);
            var messageEnvelope = new MessageEnvelope { MessageType = typeof(T).FullName, Body = serializedMessage };
            await sendEndpoint.Send(messageEnvelope);
        }
    }

    public class MessageEnvelope
    {
        public string MessageType { get; set; }
        public string Body { get; set; }
    }
}
