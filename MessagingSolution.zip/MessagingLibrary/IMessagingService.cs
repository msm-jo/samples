using System.Threading.Tasks;

namespace MessagingLibrary
{
    public interface IMessagingService
    {
        Task PublishMessageAsync<T>(T message) where T : class;
    }
}
