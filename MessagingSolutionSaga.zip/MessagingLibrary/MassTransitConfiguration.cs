using MassTransit;
using Microsoft.Extensions.DependencyInjection;

namespace MessagingLibrary
{
    public static class MassTransitConfiguration
    {
        public static IServiceCollection AddMassTransitWithRabbitMqAndSaga(this IServiceCollection services, string rabbitMqUri)
        {
            services.AddMassTransit(x =>
            {
                x.AddSagaStateMachine<OrderStateMachine, OrderState>()
                    .InMemoryRepository();

                x.UsingRabbitMq((context, cfg) =>
                {
                    cfg.Host(rabbitMqUri);
                    cfg.ReceiveEndpoint("order-saga", e =>
                    {
                        e.ConfigureSaga<OrderState>(context);
                    });
                });
            });

            services.AddMassTransitHostedService();

            return services;
        }
    }
}
