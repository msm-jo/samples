using MassTransit;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace MessagingLibrary
{
    public class GenericConsumer<T> : IConsumer<MessageEnvelope> where T : class
    {
        private static T _lastMessage;

        public Task Consume(ConsumeContext<MessageEnvelope> context)
        {
            var envelope = context.Message;
            if (envelope.MessageType == typeof(T).FullName)
            {
                _lastMessage = JsonConvert.DeserializeObject<T>(envelope.Body);
            }
            return Task.CompletedTask;
        }

        public static T GetLastMessage()
        {
            return _lastMessage;
        }
    }

    public class MessageEnvelope
    {
        public string MessageType { get; set; }
        public string Body { get; set; }
    }
}
