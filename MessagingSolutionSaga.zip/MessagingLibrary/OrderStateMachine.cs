using MassTransit;
using MassTransit.Definition;

namespace MessagingLibrary
{
    public class OrderStateMachine : MassTransitStateMachine<OrderState>
    {
        public State Submitted { get; private set; }
        public State Completed { get; private set; }

        public Event<Order> OrderSubmitted { get; private set; }

        public OrderStateMachine()
        {
            InstanceState(x => x.CurrentState);

            Event(() => OrderSubmitted, x => x.CorrelateById(context => context.Message.OrderId.ToGuid()));

            Initially(
                When(OrderSubmitted)
                    .Then(context =>
                    {
                        context.Instance.OrderId = context.Data.OrderId;
                        context.Instance.ProductName = context.Data.ProductName;
                        context.Instance.Quantity = context.Data.Quantity;
                        context.Instance.Price = context.Data.Price;
                        context.Instance.Updated = DateTime.UtcNow;
                    })
                    .TransitionTo(Submitted)
            );

            During(Submitted,
                When(OrderSubmitted)
                    .Then(context =>
                    {
                        context.Instance.Quantity += context.Data.Quantity;
                        context.Instance.Updated = DateTime.UtcNow;
                    })
                    .TransitionTo(Completed)
            );

            SetCompletedWhenFinalized();
        }
    }
}
