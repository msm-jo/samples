using MessagingLibrary;
using MessagingApi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MessagingApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IMessagingService _messagingService;

        public OrderController(IMessagingService messagingService)
        {
            _messagingService = messagingService;
        }

        [HttpPost("submit")]
        public async Task<IActionResult> SubmitOrder([FromBody] Order order)
        {
            await _messagingService.PublishMessageAsync(order);
            return Ok();
        }
    }
}
